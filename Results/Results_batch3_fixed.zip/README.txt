These tests are performed with the following settings:

normal sys:
	agents = gpt-4

React sys:
	planner = gpt-4
	agents = gpt-4

Easy_normal task 2 is a false positive!!! It finishes the task prematurely