These tests are performed with the following settings:

normal sys:
	agents = gpt-4

React sys:
	planner = gpt-4
	agents = gpt-4

Temperature = 0.0
Top_p = 0.01