These tests are performed with the following settings:

React sys:
	planner = gpt-4
	agents = gpt-3.5

Temperature = 0.0
Top_p = 0.01
seed = 235