These tests are performed with the following settings:

normal sys:
	planner = gpt-4
	good prompt

normal sys:
	planner = gpt-4
	bad prompt

Temperature = 0.0
Top_p = 0.01
seed = 235